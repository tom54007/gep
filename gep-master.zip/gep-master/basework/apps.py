from django.apps import AppConfig


class BaseworkConfig(AppConfig):
    name = 'basework'
    verbose_name = "基础数据管理"
